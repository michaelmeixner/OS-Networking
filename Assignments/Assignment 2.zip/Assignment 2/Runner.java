public class Runner extends Assignment2 {
    public static void main(String[] args) {
        Assignment2 thread = new Assignment2("WorkingDir");
        thread.start();
    }
}